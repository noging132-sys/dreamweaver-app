// placeholder, user should paste code from canvas
export default function App(){return <div>DreamWeaver App Placeholder</div>}